package com.gapperdan.hsbmdc.config;

import java.util.UUID;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
@Configuration
public class AspectConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(AspectConfig.class);	
	private static final String REF_ID = "refId";
	private static final String CLIENT = "client";

	@Before("execution(* com.gapperdan.hsbmdc.controller..*.*(..))")
	public void mdcPut(JoinPoint joinPoint) {
		//to get method name
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes())
				.getRequest();

		logger.info("added mdc key before calling "+joinPoint.getSignature().getName()+"()");



		//to get method args
		Object[] methodArgs = joinPoint.getArgs();
		for (Object oneArg: methodArgs) {
			System.out.println("arg="+oneArg);
		}
		
		MDC.put(REF_ID, UUID.randomUUID().toString().replace("-", "").substring(0, 12));
		MDC.put(CLIENT,request.getRemoteAddr());
	}	
	
	@After("execution(* com.gapperdan.hsbmdc.controller..*.*(..))")
	public void mdcRemove(JoinPoint joinPoint) {
		logger.info("removed mdc key after calling "+joinPoint.getSignature().getName()+"()");
		MDC.remove(REF_ID);
	}	
}